DROP DATABASE IF EXISTS hashing_login;

CREATE DATABASE hashing_login;